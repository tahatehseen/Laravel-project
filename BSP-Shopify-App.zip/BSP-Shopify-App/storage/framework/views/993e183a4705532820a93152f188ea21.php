<link rel="stylesheet" href="https://unpkg.com/@shopify/polaris@13.3.0/build/esm/styles.css">
<link rel="stylesheet" href="css/style.css">
<link href="https://cdn.jsdelivr.net/npm/material-icons@1.13.12/css/material-icons.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script><?php /**PATH C:\Laravel\BSP-Shopify-App\resources\views/includes/head-link.blade.php ENDPATH**/ ?>