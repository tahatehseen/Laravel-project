<footer class="footer">
    <div class="container-fluid">
        <div class="row">
                <div class="text-sm-end text-center">
                <a href="#" class="text-muted" target="_blank" rel="noopener noreferrer"> <script>
                        document.write(new Date().getFullYear())
                    </script> © Design & Developed by H3 Technologies.</a>
                </div>
        </div>
    </div>
</footer>